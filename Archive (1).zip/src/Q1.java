/*Noah Honickman
 * nhonickm
 * Assignment 4
 * MW 1400-1515
 * I did not collaborate with anyone on this project
 */
import java.util.Scanner;
public class Q1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner scanner = new Scanner(System.in);
int number;
//once the number is entered we will go into the do-loop to get our squares
do {
	System.out.println("Enter a number to get its square.");
	number = scanner.nextInt();
	
		//this if-loop ensures that the square is not printed
	if ( number != 0){
			System.out.println(" the squared value is: " + Math.pow(number, 2));
		}
		
	
}while (number != 0);
	}
}



