/*Noah Honickman
 * nhonickm
 * Assignment 4
 * MW 1400-1515
 * I did not collaborate with anyone on this project
 */
import java.util.Scanner;


public class Q4 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a number to get the sum of its harmonic series:");
		int n = scanner.nextInt();
		double x = 1;
		double sum = 0;
		//while loop will increment to get us all the terms
		while (x<= n){
			if (x % 2 == 0 ){
				x = -x;
			}
			sum = sum + 1/x;
		//the math.abs is to ensure that we don't get negatives when we do our incrementing
			x = Math.abs(x) + 1;
			
		}
	//the below lines will print our sum and log(2) which is what the series approaches as n approaches infinity
	System.out.println(sum);
	System.out.print(Math.log(2));
	}
	

}
