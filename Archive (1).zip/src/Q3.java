/*Noah Honickman
 * nhonickm
 * Assignment 4
 * MW 1400-1515
 * I did not collaborate with anyone on this project
 */
import java.util.Scanner;

public class Q3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
	System.out.println("Enter three numbers");
		int number1 = scanner.nextInt();
	int number2 = scanner.nextInt();
	int number3 = scanner.nextInt();
	
	//if not all the numbers are 0, then we will enter the loop
	while (number1 != 0 || number2 != 0 || number3 != 0)
	
	{
		
	//this loop will do the incrementing
		for(int x = number1; x< number2; x= x + number3) {
		System.out.println(x);
	}
	System.out.println(number2);
System.out.println("Enter three numbers");
	
	number1 = scanner.nextInt();
	 number2 = scanner.nextInt();
	 number3 = scanner.nextInt();
	
	
		}
	
	
	if(number1 == 0 && number2 == 0 && number3 == 0)
	{
		//the line will indicate that the program is done
		System.out.println("The program is done.");
		}
	}

}
