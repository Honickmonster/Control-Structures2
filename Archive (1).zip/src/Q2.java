/*Noah Honickman
 * nhonickm
 * Assignment 4
 * MW 1400-1515
 * I did not collaborate with anyone on this project
 */
import java.util.Scanner;

public class Q2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a number to get its times table.");
	int number = scanner.nextInt();
	//double for-loop to get all of our terms for the times table
	for(int x = 1; x<= number; x= x+1) {
	for(int y = 1; y<= number; y = y+1) {
		System.out.print(x*y);
		if (y<number) {
			System.out.print(" ");
		}
	}System.out.println();
	}
	}

}
